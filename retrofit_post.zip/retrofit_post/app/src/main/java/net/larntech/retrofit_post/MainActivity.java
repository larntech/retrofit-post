package net.larntech.retrofit_post;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {


    TextInputEditText username,fname,lname,email;
    Button regUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.username);
        fname = findViewById(R.id.fname);
        lname = findViewById(R.id.lname);
        email = findViewById(R.id.email);
        regUser = findViewById(R.id.regUser);

        regUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postUser(createRequest());
            }
        });
    }


    public UserRequest createRequest(){
        UserRequest userRequest = new UserRequest();
        userRequest.setUsername(username.getText().toString());
        userRequest.setFirst_name(fname.getText().toString());
        userRequest.setLast_name(lname.getText().toString());
        userRequest.setEmail(email.getText().toString());

        return userRequest;
    }


    public void postUser(UserRequest userRequest){
        Call<UserResponse> userResponseCall = ApiClient.getService().saveUser(userRequest);
        userResponseCall.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if(response.isSuccessful()){
                    Toast.makeText(MainActivity.this,"User saved successfully",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this,"Request failed",Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this,"Request failed "+t.getLocalizedMessage(),Toast.LENGTH_LONG).show();

            }
        });


    }

}
